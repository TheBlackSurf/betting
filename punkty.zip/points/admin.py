from django.contrib import admin
from .models import ProfilePoint
# Register your models here.

admin.site.register(ProfilePoint)