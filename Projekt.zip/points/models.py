from django.db import models
from django.contrib.auth.models import User
from django.db.models import F
from django.db import models

class AnnotationManager(models.Manager):

    def __init__(self, **kwargs):
        super().__init__()
        self.annotations = kwargs

    def get_queryset(self):
        return super().get_queryset().annotate(**self.annotations)

class ProfilePoint(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    kolejka1 = models.IntegerField(null=True, blank=True)
    kolejka2 = models.IntegerField(null=True, blank=True)
    kolejka3 = models.IntegerField(null=True, blank=True)
    kolejka4 = models.IntegerField(null=True, blank=True)
    kolejka5 = models.IntegerField(null=True, blank=True)
    kolejka6 = models.IntegerField(null=True, blank=True)
    kolejka7 = models.IntegerField(null=True, blank=True)
    kolejka8 = models.IntegerField(null=True, blank=True)
    kolejka9 = models.IntegerField(null=True, blank=True)
    kolejka10 = models.IntegerField(null=True, blank=True)
    kolejka11 = models.IntegerField(null=True, blank=True)
    kolejka12 = models.IntegerField(null=True, blank=True)
    kolejka13 = models.IntegerField(null=True, blank=True)
    kolejka14 = models.IntegerField(null=True, blank=True)
    kolejka15 = models.IntegerField(null=True, blank=True)
    kolejka16 = models.IntegerField(null=True, blank=True)
    kolejka17 = models.IntegerField(null=True, blank=True)
    kolejka18 = models.IntegerField(null=True, blank=True)
    kolejka19 = models.IntegerField(null=True, blank=True)
    kolejka20 = models.IntegerField(null=True, blank=True)
    kolejka21 = models.IntegerField(null=True, blank=True)
    kolejka22 = models.IntegerField(null=True, blank=True)
    kolejka23 = models.IntegerField(null=True, blank=True)
    kolejka24 = models.IntegerField(null=True, blank=True)
    kolejka25 = models.IntegerField(null=True, blank=True)
    kolejka26 = models.IntegerField(null=True, blank=True)
    kolejka27 = models.IntegerField(null=True, blank=True)
    kolejka28 = models.IntegerField(null=True, blank=True)
    kolejka29 = models.IntegerField(null=True, blank=True)
    kolejka30 = models.IntegerField(null=True, blank=True)
    kolejka31 = models.IntegerField(null=True, blank=True)
    kolejka32 = models.IntegerField(null=True, blank=True)
    kolejka33 = models.IntegerField(null=True, blank=True)
    kolejka34 = models.IntegerField(null=True, blank=True)
    
    objects = AnnotationManager(
        gross=F('kolejka1')+F('kolejka2')+F('kolejka3'),
    )