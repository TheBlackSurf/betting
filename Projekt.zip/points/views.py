from multiprocessing import context
from django.shortcuts import render
from .models import ProfilePoint

# Create your views here.
def viewpoint(request):
    points = ProfilePoint.objects.all()
    
    context = {
        'points':points,
    }
    
    return render(request, 'points/points.html', context)